﻿using SeleniumCSharpApp;

var MySeleniumTest = new MySeleniumTest();
MySeleniumTest.Test1();